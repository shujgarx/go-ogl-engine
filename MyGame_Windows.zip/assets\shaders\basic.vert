#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aNormal;
layout (location = 2) in vec2 aTex;

uniform mat4 uMVP;

out vec2 vTex;

void main() {
    vTex = aTex;
    gl_Position = uMVP * vec4(aPos, 1.0);
}
